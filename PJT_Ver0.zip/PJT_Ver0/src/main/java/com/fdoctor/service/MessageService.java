package com.fdoctor.service;

import com.fdoctor.vo.MessageVO;

public interface MessageService {
	

	// 메시지 전송 
	void sendmessage(MessageVO vo);
	

}







