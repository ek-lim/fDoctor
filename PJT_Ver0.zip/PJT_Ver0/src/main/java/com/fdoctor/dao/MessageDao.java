package com.fdoctor.dao;

import com.fdoctor.vo.MessageVO;

public interface MessageDao {
	
	void sendmessage(MessageVO vo);

}


