package com.fdoctor.vo;

public class HospitalVO {
	private int hid;
	private String name;
	private String address;
	private double gyungdo;
	private double wido;
	private int fdoctor;
	private int foreigner;
	private String timewday;
	private String timewend;
	private String phone;
	private String department;
	private int score;
	private String review;
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getGyungdo() {
		return gyungdo;
	}
	public void setGyungdo(double gyungdo) {
		this.gyungdo = gyungdo;
	}
	public double getWido() {
		return wido;
	}
	public void setWido(double wido) {
		this.wido = wido;
	}
	public int getFdoctor() {
		return fdoctor;
	}
	public void setFdoctor(int fdoctor) {
		this.fdoctor = fdoctor;
	}
	public int getForeigner() {
		return foreigner;
	}
	public void setForeigner(int foreigner) {
		this.foreigner = foreigner;
	}
	public String getTimewday() {
		return timewday;
	}
	public void setTimewday(String timewday) {
		this.timewday = timewday;
	}
	public String getTimewend() {
		return timewend;
	}
	public void setTimewend(String timewend) {
		this.timewend = timewend;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
}
