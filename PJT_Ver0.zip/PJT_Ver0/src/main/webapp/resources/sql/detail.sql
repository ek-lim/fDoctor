create table Detail(
name varchar(20) primary key,
review varchar(100) not null,
reg_date date
);



select*from detail;
