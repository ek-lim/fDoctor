create table Detail(
name varchar(20) primary key,
review varchar(100) not null,
hid int flroh
reg_date date
);

insert into DETAIL values('hong', 'ㅇㅇㅇ', sysdate)

select*from detail;
